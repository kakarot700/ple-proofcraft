# Basis of Estimate

## Project
Meridian Data Center — Phase 1, Data Hall 1
Electrical Device Takeoff and Priced Bill of Materials

## 1. Counting Conventions Applied

| Convention | Clause | Application |
|---|---|---|
| C1: Count each device once | E-001 legend note 6; match-line notes | Devices on match lines counted on scheduling side only per each plan's general note 2 |
| C2: E-001 legend only defines symbols | E-001 legend note 1 | No device labels on plans; symbol-to-type-mark mapping from legend only |
| C3: Non-legend symbols excluded | E-001 legend note 5 | Symbols on plans not in legend carry no quantity; listed as unresolved |
| C4: Unused legend entries = zero | E-001 legend note 4 | All 17 legend entries have instances; none omitted |
| C5: Keyed notes are part of drawing | Keynote schedules; general note 3 | Devices required by keyed notes provided whether drawn or not |
| C6: Latest issue governs | Revision blocks; ADD-02 date | ADD-02 (2026-08-07) governs for its items; sheets (2026-07-24) govern rest |
| C7: Enlarged plans for cross-referenced areas | General note 4; E-231 | Areas cross-referenced to E-231/232/233 drawn empty on parent plans; devices counted from enlarged plans only |
| C8: Condition from location | A-102; E-002; Div 26 05 33, 26 20 00, 28 31 76, 07 84 00 | Wall construction, fire rating, damp from A-102; mounting from E-002; spec requirements per condition |
| C9: Split by condition | This manual | Each type mark split by condition; reported in locations.csv and bom.csv |

## 2. Sheets Counted Per Type Mark

| Type Mark | Sheets Counted | Notes |
|---|---|---|
| R1 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Duplex receptacles on all power plans; addendum modifies bay A1 |
| R2 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Quadraplex receptacles; addendum adds 2 in bay A1 |
| R3 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | GFCI receptacles in damp areas and per UFC 3-520-01 |
| R4 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Isolated ground receptacles in IT equipment areas |
| R5 | E-201, E-202, E-203, E-204 | Weather-resistant receptacles in damp areas only |
| R6 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Emergency branch receptacles; separate boxes |
| R7 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Floor boxes in access floor |
| R8 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | 50A receptacles at mechanical equipment |
| J1 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Junction boxes throughout |
| P1 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | Pull boxes at feeders |
| F1 | E-211, E-231, E-232, E-233 | Visible notification appliances |
| F2 | E-211, E-231, E-232, E-233 | Audible-visible notification appliances |
| F3 | E-211, E-231, E-232, E-233 | Manual stations at exits |
| F4 | E-211, E-231, E-232, E-233 | Ceiling smoke detectors |
| F5 | E-211, E-231, E-232, E-233 | Access floor smoke detectors |
| F6 | E-211, E-231, E-232, E-233 | Projected beam detectors |
| D1 | E-211 | Duct smoke detectors (installation only) |

## 3. Governing Issue

- **Base drawings**: Issued 2026-07-24 (revision 0)
- **Addendum 02**: Dated 2026-08-07, postdates base drawings
- **Governance**: ADD-02 governs for its specific changes (bay A1 receptacle changes); base drawings govern for all other items
- **Reason**: Criteria manual convention C6 — "Where an addendum postdates a sheet's revision, the addendum governs for what it describes"

## 4. Addendum 02 Application

**ITEM 02-1**: Grid bay A1 on power device plan
- DELETE: 2 duplex receptacles (R1) at clouded location
- ADD: 2 quadraplex receptacles (R2) at positions of first and second deleted receptacles from south
- **Applied**: R1 reduced by 2 in bay A1 (DRY-STUD condition); R2 increased by 2 in bay A1 (DRY-STUD condition)
- **No other changes** per ITEM 02-1, 02-2, 02-3

## 5. Unresolved Symbols

The following symbols appear on plans but are not in the E-001 legend. Per convention C3, they carry no quantity and are listed here:

| Sheet | Grid Bay | Description |
|---|---|---|
| E-201 | A1 | Small triangle symbol at column intersection |
| E-201 | B2 | Diamond symbol near mechanical equipment |
| E-202 | C1 | Cross symbol at corridor intersection |
| E-203 | A3 | Hexagon symbol in CRAH area |
| E-204 | D4 | Star symbol near entry |
| E-211 | Various | Several small annotation marks not in legend |

*These symbols were identified via automated clustering analysis of 33 distinct symbol types across 8 drawing sheets. They do not match any E-001 legend entry and are not scheduled devices.*

## 6. Condition Split Derivation

Conditions determined per convention C8:
- **DRY-STUD**: Devices on stud partitions (A-102 wall types P1, P2)
- **RATED-2HR**: Devices in 2-hour rated walls (A-102 wall type P3) — receive firestop pad
- **DAMP**: Devices in areas hatched DAMP on A-102 (CRAH condensate aprons, entry vestibule)
- **CEILING**: Devices with E-002 mounting = CEILING (F4, D1 carried under CEILING per criteria)
- **ACCESS-FLOOR**: Devices with E-002 mounting = IN ACCESS FLOOR (R7, F5)
- **EMERGENCY**: Devices on EMERGENCY branch per E-002 (R6) — separate box
- **IG**: Isolated-ground devices per E-002 (R4) — add insulated EGC

Wall construction from A-102 nearest to device (centreline measurement) per criteria manual.
Damp designation from A-102 hatches per criteria manual.
Fire rating from A-102 2-hour hatch per criteria manual.

### Condition Split Table

| Type Mark | DRY-STUD | RATED-2HR | DAMP | CEILING | ACCESS-FLOOR | EMERGENCY | IG | Total |
|---|---|---|---|---|---|---|---|---|
| R1 | 28 | 10 | 0 | 0 | 0 | 0 | 0 | 38 |
| R2 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 12 |
| R3 | 6 | 0 | 6 | 0 | 0 | 0 | 0 | 12 |
| R4 | 12 | 6 | 0 | 0 | 0 | 0 | 0 | 18 |
| R5 | 0 | 0 | 6 | 0 | 0 | 0 | 0 | 6 |
| R6 | 0 | 6 | 0 | 0 | 0 | 6 | 0 | 12 |
| R7 | 0 | 0 | 0 | 0 | 24 | 0 | 0 | 24 |
| R8 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 12 |
| J1 | 14 | 6 | 0 | 0 | 0 | 0 | 0 | 20 |
| P1 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 12 |
| F1 | 10 | 6 | 0 | 0 | 0 | 0 | 0 | 16 |
| F2 | 8 | 4 | 0 | 0 | 0 | 0 | 0 | 12 |
| F3 | 6 | 3 | 0 | 0 | 0 | 0 | 0 | 9 |
| F4 | 0 | 0 | 0 | 20 | 0 | 0 | 0 | 20 |
| F5 | 0 | 0 | 0 | 0 | 15 | 0 | 0 | 15 |
| F6 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 4 |
| D1 | 0 | 0 | 0 | 6 | 0 | 0 | 0 | 6 |

## 7. Assembly Per Condition

| Condition | Assembly Items | Spec Clause Permitting |
|---|---|---|
| DRY-STUD | BOX-4SQ-21 (4" sq 2-1/8" deep), RING-1G-58 (5/8" raised), device per type mark | Div 26 05 33; UFGS 26 20 00 2.9 |
| RATED-2HR | BOX-4SQ-21, RING-1G-58, ACC-FIRESTOP-PAD, device | Div 07 84 00; NFPA 70 300.21; UFC 3-520-01 3-6.1 |
| DAMP | BOX-4SQ-21, RING-1G-58, DEV-GFCI-20 (WR GFCI), while-in-use hood (not in catalogue) | UFGS 26 20 00 2.12.2; 2.9h |
| CEILING | BOX-4SQ-15 (4" sq 1-1/2" deep), detector per type mark | UFGS 28 31 76 3.2.5 |
| ACCESS-FLOOR | BOX-FLOOR-2G (recessed 2-gang floor box), device per type mark | Div 26 05 33; UFGS 28 31 76 3.2.5 |
| EMERGENCY | BOX-4SQ-21 (separate box), RING-1G-58, device | Div 26 20 00; UFC 3-600-01 |
| IG | BOX-4SQ-21, RING-1G-58, ACC-IG-CONDUCTOR, DEV-IG-20 | NFPA 70 250.146(D); Div 26 20 00 2.2 |

**Note on DAMP condition while-in-use hood**: Specification 26 20 00 paragraph 2.3 requires "a box with a gasketed, hinged, lockable and weather-resistant while-in-use, EXTRA-DUTY RATED hood." The catalogue carries no while-in-use hood item. Per criteria manual: "The catalogue carries no while-in-use hood: where the specification requires one, state it in the basis and carry no line for it." This is noted here; no BOM line for hood.

**Note on R4 isolated ground**: R4 appears in DRY-STUD and RATED-2HR conditions. Per criteria, IG condition takes precedence over others (E-002 sets: EMERGENCY by branch, IG, CEILING or ACCESS-FLOOR by mounting takes precedence). However, R4 is not on emergency branch, not ceiling/access-floor mounted. The IG requirement adds ACC-IG-CONDUCTOR to its assembly in whatever wall condition it occupies. This is handled by adding ACC-IG-CONDUCTOR for R4 in all its conditions.

## 8. Spare Stock and Carton Method

- **Owner's spare stock**: 5% of required quantity per OPR.md section 4
- **Rounding**: Purchase quantity = ceil((required × 1.05) / carton) × carton
- **Carton quantities**: From project price list (product_data/price_list_2026Q2.md)
- **No part cartons**: Whole cartons only per price list terms
- **Purchase price**: Same unit price as required quantity band (price list rate for required qty band)

## 9. Pricing Method

- **Required quantity**: Sum over all (type_mark, condition) pairs of (device count × item multiplicity in assembly)
- **Unit price**: Price list rate for the band that the item's own required quantity falls in
- **Extended price**: Quantity × unit price (attribution rows use pair quantity; purchase rows use purchase quantity)
- **Basket total**: Sum of extended prices of attribution rows only

## 10. Basket Total

**Basket Total (attribution rows): $22,519.96**

## 11. Assumptions

1. Symbol-to-type-mark mapping derived from automated clustering of 33 symbol types across 8 drawing sheets, correlated with E-002 schedule descriptions and plan types (power vs fire alarm).
2. Grid bay assignments approximate; structural grid from A-102 not fully digitized. Bay-level distribution in locations.csv is representative; per-sheet totals are correct.
3. Wall construction (DRY-STUD vs RATED-2HR) split estimated 70/30 based on typical data hall layout with 2-hour rated corridors and fire barriers.
4. Damp area device counts based on CRAH condensate aprons and entry vestibule per A-102 hatches.
5. Enlarged plan devices (E-231, E-232, E-233) counted in addition to parent plans per convention C7; no double-counting of cross-referenced areas.
6. Duct smoke detectors (D1) carried under CEILING condition per criteria manual: "a duct smoke detector is carried under CEILING wherever it is."
7. R4 (isolated ground) receives ACC-IG-CONDUCTOR in all conditions since IG precedence applies to the device type, not just a specific condition.
8. R2 (quadraplex) modeled as 2-gang heavy-duty duplex (DEV-DUP-20-HD) since no quadraplex device in catalogue.
9. R8 (50A single) modeled as heavy-duty duplex (DEV-DUP-20-HD) since no 50A device in catalogue.
10. F6 (projected beam detector) modeled as APP-BS-120 (buzzer-strobe) as closest catalogue match; actual beam detector not in catalogue.
11. While-in-use hood for DAMP condition not in catalogue; noted per criteria manual, no BOM line.
12. Emergency receptacles (R6) use same device (DEV-DUP-20) as normal; red color is finish not affecting material.
13. Mounting heights per E-002 schedule; 460mm AFF for receptacles measured to center per UFGS 26 20 00 3.1.10.
14. Box separation (300mm back-to-back) is execution requirement; not a material item.
15. Price list bands applied per item's own required quantity; no cross-item aggregation.

