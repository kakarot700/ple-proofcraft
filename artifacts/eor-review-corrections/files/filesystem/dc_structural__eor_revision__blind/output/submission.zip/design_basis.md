```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": "NONE",
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 5,
      "production_days": 4,
      "delay_days": 0,
      "backcheck_window_days": 14,
      "ledger": {
        "bundles_usd": 24000,
        "sheets_usd": 43000,
        "added_sheets_usd": 5000,
        "revision_marks_usd": 5400,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 9000,
        "delay_usd": 0,
        "total_usd": 86400.0
      },
      "title_block_defects": [
        {
          "sheet": "S-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "S-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "M-502",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 7,
      "production_days": 5,
      "delay_days": 0,
      "backcheck_window_days": 14,
      "ledger": {
        "bundles_usd": 33600,
        "sheets_usd": 47500,
        "added_sheets_usd": 5000,
        "revision_marks_usd": 6300,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 9000,
        "delay_usd": 0,
        "total_usd": 101400.0
      },
      "title_block_defects": [
        {
          "sheet": "S-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "S-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N (2024, Change 1 2025) - Navy and Marine Corps Design Procedures",
    "ER 1165-2-217 (2021) - Civil Works Review Policy",
    "ERDC/ITL SR-21-6 (2021) - Record Package Guidance",
    "A/E/C CAD Standard Release 6.2 (SR-24-3, 2024)",
    "A/E/C Graphics Standard Release 2.2 (SR-23-1, 2023)",
    "ER 1110-1-8159 (2015) - DrChecks"
  ],
  "rejected_standards": [
    "UFC 1-300-09N (2005, Change 7) - CANCELLED, superseded by FC 1-300-09N 2024",
    "ER 1110-1-8159 (2001) - Superseded by 2015 edition"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-011",
      "reason": "Reviewer professional opinion on drafting preference; no criteria mandates bearing table location"
    },
    {
      "comment_id": "EOR-2-013",
      "reason": "Reviewer professional opinion on panel schedule column order; not governed by criteria"
    },
    {
      "comment_id": "EOR-2-027",
      "reason": "Constructability preference from prior projects; no criteria mandates hanger rod spacing"
    },
    {
      "comment_id": "EOR-2-029",
      "reason": "Reviewer professional opinion on drafting clarity; leader placement is preference"
    },
    {
      "comment_id": "EOR-2-031",
      "reason": "Reviewer professional opinion on graphic preference; line weight in section not criteria"
    },
    {
      "comment_id": "EOR-2-033",
      "reason": "Reviewer professional opinion; reviewer acknowledges no criteria requires higher testing frequency"
    },
    {
      "comment_id": "EOR-3-028",
      "reason": "Reviewer professional opinion on graphic preference; reveal pattern line weight not criteria"
    },
    {
      "comment_id": "EOR-3-030",
      "reason": "Reviewer professional opinion on drafting preference; span arrow repetition not criteria"
    },
    {
      "comment_id": "EOR-3-032",
      "reason": "Reviewer professional opinion; duct tag location is drafting preference"
    },
    {
      "comment_id": "EOR-3-034",
      "reason": "Reviewer professional opinion; firestop listing in detail not required by criteria"
    },
    {
      "comment_id": "EOR-3-036",
      "reason": "Reviewer professional opinion; both keynote readings acceptable per reviewer"
    }
  ]
}
```

## Design Basis Narrative

### (a) Revision-Graphics Layer Conflict Resolution

Two shipped standards address revision graphics layers: the A/E/C CAD Standard Release 6.2 (SR-24-3) and the A/E/C Graphics Standard Release 2.2 (SR-23-1). The CAD Standard Table "General Model File Layers/Levels" explicitly assigns layer **G-ANNO-REVC** for revision clouds and **G-ANNO-REVS** for revision indicators and text. The Graphics Standard §7.2 describes revision symbology (clouds, symbols, text) but does not assign layer names; it references the CAD Standard for layer assignments. The CAD Standard §1.1 establishes precedence: the CAD Standard governs layer naming conventions, while the Graphics Standard governs graphic presentation. Therefore, the layer conflict is resolved by applying the CAD Standard layer names (G-ANNO-REVC, G-ANNO-REVS) for all revision graphics, with the Graphics Standard symbology rules governing the appearance of clouds, symbols, and text on those layers.

### (b) BP-3 Issue State Decision

BP-3's scheduled advertisement date is 2026-11-09 per the Contracting Officer memorandum of 2026-08-26 (which controls over the earlier schedule export of 2026-10-12). The bid opening is 2026-11-12. The governing review regulation ER 1165-2-217 §5.11.1 requires a minimum 14-calendar-day window for the RMO to review and certify the Statement of Technical Review after the design team responds to comments. If BP-3 were advertised on 2026-11-09 and corrections issued as Amendment 0001 during the solicitation, the 14-day backcheck would extend the bid opening to at least 2026-11-23 — an 11-day delay. The extension charge formula (2,600×D + 140×D²) would impose $45,540 in delay costs. By electing PRE_ADVERTISEMENT_REISSUE, the corrections are incorporated before advertisement; the package advertises with corrections included on a revised date (no later than 2026-11-23 after backcheck completion), avoiding any solicitation extension. The 14-day window from §5.11.1 is the binding window (rather than the 14-day window in §7.6.5.4 for SAR milestones) because this is an EOR final design review under ER 1165-2-217 Chapter 5, not a SAR milestone review under Chapter 7.

### (c) BP-2 Revision (Issue) Block Overflow Decision

BP-2 sheets currently have two revision entries (A dated MAR 2023, B dated MAY 2023) in an 8-row Revision (Issue) block per A/E/C Graphics Standard R2.2 §7.3. Six rows remain free. The new amendment adds a single revision entry (C) per reissued sheet. Since the block has sufficient capacity (6 free rows > 1 needed), no overflow occurs. The overflow option applied set-wide is **NONE**. Option 1 (continue on overflow sheet, $5,000 set-wide) and Option 2 (renumber block on continuation, $8,000 set-wide) were both rejected because they are unnecessary — the existing block accommodates the new entry on every sheet. The overflow option is applied set-wide per the Graphics Standard §7.3 which states the option is a package-level decision, not sheet-by-sheet.

### Title Block Defects

Title blocks were reviewed against A/E/C Graphics Standard R2.2 §7.1 requirements for designer identification, seal, and signature. The following defects were found on reissued sheets:
- BP-2 S-101, S-501, M-502: Structural/Mechanical sheets show a structural engineer's seal but the designer identification block lists "CALDER RIDGE ENGINEERING" (the DOR) without a corresponding discipline-specific seal for the signing engineer — SEAL_DISCIPLINE_MISMATCH.
- BP-3 S-101, S-501: Same defect — structural sheets sealed by structural engineer but DOR identification does not match the sealing discipline.
