# Continuation Sheet - Work Order 74213

## BP-2: Central Utility Plant and Site Utilities (Solicitation N40085-26-R-2041)

### Issue State
**AMENDMENT** — The package was advertised on 2026-07-06. Per FAR 52.236-25 and NAVFAC policy, corrections to an advertised solicitation must be issued as a numbered amendment. The Contracting Officer memorandum of 2026-08-26 assigns the next change number **0003** (two prior amendments 0001 and 0002 have been issued).

### Change Documentation
**Amendment 0003** incorporates the accepted EOR final design review comments (15 valid, 6 void) dated 2026-08-11 through 2026-08-19, exported 2026-08-24. The corrections affect 14 existing sheets and add 2 new sheets (M-503, S-202). All revisions are marked with revision letter **C** on existing sheets and **A** on new sheets, dated SEP 2026.

### Drawing List — Amendment 0003
| Sheet | Title | Action |
|-------|-------|--------|
| C-101 | SITE UTILITY PLAN | REPLACE |
| C-301 | SITE UTILITY SECTIONS | REPLACE |
| G-001 | COVER SHEET | REPLACE |
| GI-001 | DRAWING INDEX | REPLACE |
| M-101 | CUP CHILLED WATER PLAN | REPLACE |
| M-301 | CHILLED WATER PLANT SECTIONS | REPLACE |
| M-401 | CHILLER BAY ENLARGED PLAN | REPLACE |
| M-502 | EQUIPMENT ANCHORAGE DETAILS | REPLACE |
| M-503 | CHILLER PAD ANCHORAGE DETAILS | ADD |
| S-101 | CUP FOUNDATION PLAN | REPLACE |
| S-102 | CUP ROOF FRAMING PLAN | REPLACE |
| S-201 | CUP EXTERIOR ELEVATIONS | REPLACE |
| S-202 | BRACED BAY FRAMING ELEVATIONS | ADD |
| S-301 | CUP BUILDING SECTIONS | REPLACE |
| S-501 | FOUNDATION DETAILS | REPLACE |
| S-502 | FRAMING DETAILS | REPLACE |

### Schedule Impact
Production starts 2026-08-31. 16 sheets at 4 sheets/day = 4 production days. Bundle setup and reprographics: 5 bundles × 3 days = 15 calendar days (concurrent). Finish ≈ 2026-09-15. Amendment issued well before bid opening 2026-09-28. No solicitation extension required.

---

## BP-3: Data Hall 210 Shell and Interiors (Solicitation N40085-26-R-3018)

### Issue State
**PRE_ADVERTISEMENT_REISSUE** — The Contracting Officer memorandum of 2026-08-26 schedules advertisement for 2026-11-09 and offers the DOR the choice to hold advertisement and incorporate corrections, or advertise on schedule and issue as Amendment 0001. 

The governing review regulation ER 1165-2-217 §5.11.1 requires a minimum 14-calendar-day backcheck window for the RMO to review and certify the Statement of Technical Review after the design team responds to comments. If the package were advertised on 2026-11-09 and corrections issued as an amendment, the 14-day backcheck would push the bid opening (currently 2026-11-12) to at least 2026-11-23, an 11-day extension costing $45,540 in escalating delay charges (2,600×D + 140×D²). Holding advertisement to 2026-11-23 (14 days after incorporating corrections and completing backcheck) avoids the solicitation extension cost and is the lower-cost option.

Accordingly, the DOR elects **PRE_ADVERTISEMENT_REISSUE**: the corrections are incorporated into the design before advertisement; the package advertises with the corrections included; no amendment is issued during the solicitation period.

### Change Documentation
This package is **not** issued as a change to a solicitation. The corrections are incorporated in the pre-advertisement reissue dated NOV 2026. The drawing list below reflects the sheets as they will appear in the advertised package.

### Drawing List — Pre-Advertisement Reissue
| Sheet | Title | Action |
|-------|-------|--------|
| A-001 | PARTITION TYPES AND KEY PLAN | REPLACE |
| A-101 | DATA HALL 210 FLOOR PLAN | REPLACE |
| A-102 | DATA HALL 210 ROOF PLAN | REPLACE |
| A-301 | BUILDING SECTIONS | REPLACE |
| A-402 | TELECOM ENTRANCE ROOM ENLARGED PLAN | ADD |
| A-501 | WALL SECTIONS AND DETAILS | REPLACE |
| A-502 | ROOF DETAILS | REPLACE |
| E-102 | DATA HALL 210 LIGHTING PLAN | REPLACE |
| E-501 | ELECTRICAL DETAILS | REPLACE |
| G-001 | COVER SHEET | REPLACE |
| GI-001 | DRAWING INDEX | REPLACE |
| M-101 | DATA HALL 210 CRAH PLAN | REPLACE |
| M-502 | CONTAINMENT WALL DUCT PENETRATION DETAILS | ADD |
| S-101 | DATA HALL 210 FOUNDATION PLAN | REPLACE |
| S-301 | DATA HALL 210 FRAMING SECTIONS | REPLACE |
| S-501 | STRUCTURAL DETAILS | REPLACE |
| T-101 | DATA HALL 210 TELECOM PATHWAY PLAN | REPLACE |
| T-501 | TELECOM DETAILS | REPLACE |

### Schedule Impact
Production starts 2026-08-31. 18 sheets at 4 sheets/day = 5 production days. 7 bundles × 3 days = 21 calendar days (concurrent). Finish ≈ 2026-09-20. Corrected package ready well before revised advertisement date. No solicitation extension required.

---

## Governing Standards Applied
- FC 1-300-09N (2024, Change 1 2025) — Navy Design Procedures (change numbers, amendment procedures)
- ER 1165-2-217 (2021) — Civil Works Review Policy (backcheck window, comment resolution)
- ERDC/ITL SR-21-6 (2021) — Record Package Guidance (revision graphics, revision block)
- A/E/C CAD Standard Release 6.2 (SR-24-3, 2024) — Layer assignments (G-ANNO-REVC, G-ANNO-REVS)
- A/E/C Graphics Standard Release 2.2 (SR-23-1, 2023) — Revision graphics, revision block format
- ER 1110-1-8159 (2015) — DrChecks mandatory use
- UFC 1-200-01, 3-101-01, 3-301-01, 3-580-01 — Technical criteria cited in review comments
