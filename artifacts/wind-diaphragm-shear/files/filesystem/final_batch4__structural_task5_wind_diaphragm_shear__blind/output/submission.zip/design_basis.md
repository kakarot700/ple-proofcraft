# Design Basis Narrative

Building A2 — Roof Diaphragm and Perimeter Shear Walls
Northern Divide Data Campus, Lewis and Clark County, Montana
Kestrel Ridge Structural Engineers, PLLC

---

## Table 1: Design Values

| item | value | source |
|------|-------|--------|
| Kzt | 1.19 | TS-2026-02 §4.1 |
| Ke | 0.8671 | ALTA-2025-77 §1.1 / ASCE 7-16 |
| q_h_psf | 28.7 | EOR-NDDC-A2-S01 §2.5 / ASCE 7-16 |
| screen_wall_top_ft | 36.0 | SR-2026-118 §3.3 |
| asbuilt_opening_panel | N108, N109 | SR-2026-118 §4.1 / S-201 Rev C |
| asd_combination | 0.6D + 0.6W | EOR-NDDC-A2-S01 §3.1 / AHJ NDDC-AHJ-014 |
| omega_d | 2.0 | CDS-B36 Table 3 / EOR-NDDC-A2-S01 §6.2 |
| analysis_method | DIAPH-MT 1.0 (smeared orthotropic membrane + bar chords) | EOR-NDDC-A2-S01 §4.1 |
| mesh_level | L2 (H = 5 ft) | EOR-NDDC-A2-S01 §4.2 |

## Table 2: Governing Wind Scenario per Wall Line

| line | governing scenario |
|------|------------------|
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W08 |
| E2 | W05 |

## Conflicts Resolved

1. **Precast panel openings**: PC-S01 Rev 2024 (Panel Schedule) shows no openings on panels N108 and N109. However, SR-2026-118 Roof Line Scan Report §4.1 and S-201 Rev C Roof Framing Plan both show 16 ft wide × 14 ft high openings in these panels. **Resolution**: The as-built geometry from the 2026 scan and Rev C drawings governs over the 2024 fabrication schedule. Openings incorporated in pier leg calculation and wind load distribution.

2. **Roof geometry**: The 2024 structural drawings show a clean 240 ft × 180 ft rectangle. The 2026 federated model (NDDC-A2_Federated_Model_2026.ifc) and roof line scan (SR-2026-118) reveal two deviations: (a) a generator yard re-entrant notch at x ∈ [180, 240], y ∈ [140, 180]; (b) a mechanical well opening at x ∈ [100, 140], y ∈ [100, 130]. **Resolution**: As-built 2026 geometry used for diaphragm mesh, panel layout, and load path.

3. **Mean roof height for q_h**: WT-2026-07 §2 states coefficients are referenced to q_h at mean roof height but does not give a numeric value. ASCE 7-16 defines mean roof height for flat roofs with parapets as the roof deck elevation. **Resolution**: Used top of deck = 28.0 ft above finished floor per SR-2026-118 §3.1. Parapet pressures evaluated at panel top elevations (31 ft typical, 36 ft screen wall).

4. **Deck catalogue safety factor**: CDS-B36 Table 3 lists nominal shear strength V_nom and shear stiffness G'. EOR-NDDC-A2-S01 §6.2 requires ASD capacity = V_nom / Ω_D. The catalogue does not explicitly state Ω_D. **Resolution**: Industry standard for steel deck diaphragms per SDI DDM04 is Ω_D = 2.0 for ASD; used Ω_D = 2.0.

5. **Chord allowable stresses**: KRS-CH Table 1 provides allowable tension and compression. EOR-NDDC-A2-S01 §7.1-7.2 requires ASD chord forces ≤ allowables. **Resolution**: Direct comparison of ASD forces (0.6 × strength) to tabulated allowables; no additional factor applied.

6. **Wind study revision**: The project folder contains a Hall B lateral study (HallB_Lateral_Study_2023.pdf) for a different building. **Resolution**: Ignored; not applicable to Building A2.

7. **Superseded criteria**: EOR-NDDC-A2-S01 Rev 0 (3 May 2024) is superseded by Rev 2 (14 August 2026). **Resolution**: Used Rev 2 exclusively.

