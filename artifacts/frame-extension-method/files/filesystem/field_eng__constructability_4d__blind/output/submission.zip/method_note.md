# Method Note — Frame Extension Over Occupied Ground Floor

## Governing Documents and Disagreements

The method package is governed by TWP-09 revision C (Temporary Works Procedure), which supersedes revision B. Where the issued activity list and zone work schedule disagree with each other, TWP-09 clause 3.1 controls: dependencies in the activity list are mandatory and may not be dropped. The design model schedules (storey, grid, column, slab, zone) are the fixed design basis. The five adopted public criteria (29 CFR 1926.451, .703, .250, .34, .1408) set the minimum safety and performance requirements. The catalogues (shoring, scaffold, concrete mixes, duty classes) provide the component capacities and costs.

## Striking and Reshoring Method

Slabs may be struck at the mix's early-strike age (M40-PUMP: 7 days, M50-HE: 4 days) only where the slab is reshored as the original shores are removed, per TWP-09 clause 6.3 and 29 CFR 1926.703(b)(10). Otherwise, forms and shores remain until the full-strength age of 28 days. This package adopts early striking with reshoring for all zone-lifts where the schedule requires striking before 28 days: original shoring (selected from SP-09, SP-13, SP-16, SP-20 based on load and extension) is struck at the early-strike age, and reshoring to RS-16 posts at 8 ft centres in both directions is installed simultaneously. Reshoring remains in place until the slab reaches 28 days. The reshoring occupies 25% of the zone's soffit area in the yard (TWP-09 clause 8.3). This approach minimizes the time shoring occupies the limited yard stock (3600 sf) while satisfying the strength requirement.

## Zone Constraints

**Bands A–D (Zones A–D, pump-placed concrete):** These zones are served by the concrete pump from the west. The scaffold duty is light duty for zones without occupation below, and medium duty where the ground floor remains occupied (Z-A-N, Z-A-S, Z-B-N, Z-B-S, Z-C-N, Z-C-S per existing_occupation.csv). Medium duty requires a protective deck on the shoring (15 psf additional). Shoring design load = slab self-weight (312.6 psf) + 10 psf formwork + 50 psf live load (pump) + 15 psf protective deck where required. Maximum shoring extension is the soffit-to-lift-base height minus 0.75 ft form assembly (L2: 13.83 ft, L3: 13.84 ft, L4: 13.83 ft). Shore spacing is selected from {3.0, 3.5, 4.0, 4.5, 5.0} ft to keep load per post within the chosen post's rated capacity.

**Bands E–G (Zones E–G, crane-and-bucket placement):** Heavy duty scaffold required per TWP-09 clause 5.3. Shoring live load is 75 psf (bucket). No protective deck needed as ground floor is not occupied below these bands. Heaviest picks are 8746 lb (24" columns) — well within crane capacity at all standing positions.

**Stair core zones (Z-A-N, Z-B-S, Z-E-S):** These carry a stair core. TWP-09 clause 7.3 limits shoring to at most one stair-core zone per day. The sequence staggers these zones to satisfy this.

**Overhead power line (34.5 kV, north boundary):** TWP-09 clause 9.2 adopts Option 3: demarcate the work zone so no part of equipment, load line, or load comes closer than the Table A minimum approach distance of 10 ft. The crane standing positions (CP-W, CP-C, CP-E) are 155 ft from the line. Demarcated radius is set to the zone radius (≤140 ft) and does not exceed 155 - 10 = 145 ft. All picks satisfy this.

## Margins Applied

- **Shoring post capacity:** Selected post type provides rated capacity ≥ design load per post (zone design load × spacing²) with the smallest adequate post to minimize cost. Typical margin 10–30% above demand.
- **Scaffold platform capacity:** Platform width adjusted so PL-95 plank capacity meets 4× maximum intended load per bay (TWP-09 clause 4.1). Minimum 18 in width (clause 4.2). Typical margin 5–15% above 4× requirement.
- **Height-to-base ratio:** Scaffold system and tie pattern selected so each tied segment satisfies height/base ≤ 4.0 (TWP-09 clause 4.4). SF-3 (3 ft base) used for L2 (18.75 ft), SF-5 (5 ft base) for L3 (35.42 ft), SF-7 (7 ft base) for L4 (52.08 ft). Ties placed at 4:1 height (floored to frame multiple), then at 20 ft (narrow) or 26 ft (wide) intervals, with top segment ≤ 4:1. All segment ratios ≤ 4.0.
- **Tie intervals:** Ties at 4:1 height, then every 20 ft (SF-3) or 26 ft (SF-5, SF-7), with top tie within 4:1 height of top. Horizontal interval ≤ 30 ft. Ties snapped to nearest frame height multiple below the interval.
- **Crane capacity:** Rated capacity at working radius exceeds heaviest pick by ≥20% for all zone-lifts. Radius verified ≤ standing position max radius (140 ft).
- **Yard stock:** Peak shoring demand ≤ 3600 sf, peak scaffold face ≤ 120 ft, peak laydown ≤ 16 units, verified by daily resource simulation.
- **Crane hours:** Daily crane hours ≤ 10, verified by scheduling.
- **Crew:** Concurrent activities ≤ 8 gangs, verified by scheduling.
- **Egress:** At most 1 stair-core zone shored per day, verified by scheduling.
- **Completion:** Programme finishes within 250-day deadline.

## Attribution

The building design data (storey elevations, column grid and sections, slab thickness, stair cores) is derived from:
LivingBIM Dataset: As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images. DOI 10.5281/zenodo.17934615. Licensed CC BY 4.0.
