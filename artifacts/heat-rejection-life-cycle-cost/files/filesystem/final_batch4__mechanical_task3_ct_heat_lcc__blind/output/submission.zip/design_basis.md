# Design Basis — Condenser Water Heat Rejection Replacement
## Papago Federal Center, Phoenix, Arizona — 95% Construction Documents

---

## Governing Documents

The following documents govern this design, in order of precedence:

1. **DC-02** — Design Criteria Memorandum (primary design criteria)
2. **EC-01** — Life-Cycle Cost Analysis Criteria (federal LCC rules)
3. **Spec 23 65 00** — Cooling Tower Specification Section
4. **WT-01** — Water Treatment Programme Memorandum
5. **Vendor Submittals** — CTX-0800 cooling tower cells, DE-3 drift eliminators, chiller schedules, pump schedules
6. **Climate Data** — Phoenix Sky Harbor TMY3 station records
7. **Site Correspondence** — Reclaimed water allocation letters, electric utility rate confirmation
8. **RFI Responses** — Clarifications on roof mechanical sheet revision, equalizing lines, basin heaters, CTI basis

---

## Document Conflicts (per DC-02 Appendix B)

CONFLICT 1: ADOPTED DC-02 Section 2.1 | SET ASIDE Climate Data Table 2
**Subject:** Design outdoor wet-bulb temperature basis.  
DC-02 Section 2.1 specifies 72°F wet-bulb (0.4% annual) for cooling tower sizing. The climate data library (Phoenix Sky Harbor TMY3) Table 2 lists 73°F for the same percentile.  
**Resolution:** Adopt DC-02 Section 2.1 value of 72°F as the governing design wet-bulb. DC-02 is the project-specific criteria document that explicitly governs tower sizing; the climate data is reference material. The 1°F difference is within typical variability and the DC-02 value is more conservative (lower WB = larger approach = more conservative tower selection).

CONFLICT 2: ADOPTED WT-01 Table 3 | SET ASIDE DC-02 Section 5.3
**Subject:** Maximum allowable cycles of concentration.  
DC-02 Section 5.3 states a blanket maximum of 5.0 cycles. WT-01 Table 3 provides a temperature-dependent schedule: 7.0 at CWR ≤75°F, 6.0 at 76–80°F, 5.5 at 81–85°F, 5.0 at 86–89°F, 4.5 at ≥90°F.  
**Resolution:** Adopt WT-01 Table 3 as governing. WT-01 is the specialized water treatment document that defines the chemistry basis; DC-02 Section 5.3 provides a simplified conservative value for preliminary calculations. The design uses the WT-01 schedule, which at the design CWR of 89°F yields 5.0 cycles — consistent with DC-02's value at the design point but allowing higher cycles at lower off-design return temperatures, reducing water consumption.

CONFLICT 3: ADOPTED DC-02 Appendix A.1 (SATURATED-EXIT) | SET ASIDE Vendor Performance Data (LOSS-FACTOR)
**Subject:** Evaporation formulation for water balance and allocation checks.  
The vendor performance data uses a loss-factor method (evaporation = heat rejection × 0.75 / 1000). DC-02 Appendix A.1 prescribes the saturated-exit formulation (evaporation = heat rejection / 525,000 at design conditions, varying with exit enthalpy).  
**Resolution:** Adopt DC-02 Appendix A.1 saturated-exit method as the declared `EVAPMETHOD`. DC-02 is the governing criteria memorandum and its appendix explicitly defines the calculation method for the LCCA and allocation compliance. The saturated-exit method is more physically rigorous and is the project's declared basis. The water balance and annual makeup calculations use this method consistently.

---

## Calculation Methods

### Design Point Capacity (Merkel Method)
- Tower performance evaluated using the Merkel number approximation: `Capacity = Rated_Tons × (Range/10) × (7/Approach) × Airflow_Ratio`
- Rated capacity from vendor submittal (CTX-0800-U: 580 tons at CTI conditions: 95°F HW, 85°F CW, 78°F WB, 10°F range, 7°F approach)
- Design point: 79°F CWS, 89°F CWR, 72°F WB, 10°F range, 7°F approach, 100% airflow

### Off-Design Simulation
- Scenario bins derived from Phoenix Sky Harbor TMY3 data (25 bins covering full year, 8,760 hours scaled to 8,760)
- For each bin: load fraction from wet-bulb correlation, CWS from reset schedule (max(65, WB+7, min_ECWT)), fixed 10°F range
- Airflow ratio modulated to maintain approach: `min(1.0, (7/(CWS-WB))^1.5)` when CWS > WB
- Cell staging: all cells on above 30% load; one cell off at 15–30%; two cells off below 15% (minimum 1 cell)
- Chiller staging: one chiller per 500 tons (CUP/ANNEX) or 425 tons (LAB), minimum 1 chiller
- Fan power: `bhp × 0.746 / motor_eff` with cubic airflow reduction
- Pump power: cubic flow reduction from design, motor+drive efficiency 0.93×0.94
- Chiller power: base kW/ton + 0.015 kW/ton per °F above 79°F CWS, part-load factor 0.3+0.7×PLR²

### Water Balance (Saturated-Exit Method)
- Evaporation: `Heat_Rejection_BTUH / 525,000` (at design; varies with exit conditions)
- Drift: `CW_Flow × 0.0005%` (DE-3 certified)
- Blowdown: `(Evaporation + Drift) / (COC - 1)` with COC from WT-01 Table 3 per CWR
- Makeup: `Evaporation + Drift + Blowdown`
- Annual totals integrated over scenario bins; peak day at design conditions

### Life-Cycle Cost Analysis (per EC-01)
- Discount rate: 3% real; Study period: 25 years; Construction period: 1 year
- UPV* electricity: 18.5; UPV* water: 20.1; UPV non-fuel: 19.2
- Energy cost: annual kWh × $0.082 + peak kW × $14.50 × 12
- Water cost: annual makeup kgal × $4.75 + annual blowdown kgal × $6.80
- O&M: 2% of investment annually
- Replacement: fan motors at year 15 (50% probability, half cost)
- Salvage: 10% of investment at year 25
- LCC = Investment + PV(Energy) + PV(Water) + PV(O&M) + PV(Replacement) - PV(Salvage)
- Basic Design LCC = 1.12 × LCC (code-minimum reference per EC-01 Section 3)
- Net Savings = Basic Design LCC - LCC

---

## Governing Constraints per Plant

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.004)
GOVERNING CONSTRAINT ANNEX: electrical capacity (relative margin 0.012)
GOVERNING CONSTRAINT LAB: structural capacity (relative margin 0.051)

**Margin Calculations:**
- **CUP:** MCC total (fan+pump) = 526 kW vs. spare 528 kW → margin = (528-526)/528 = 0.0038 ≈ 0.004. Peak coincident demand (911 kW) is not MCC-limited (MCC only feeds fans+pumps). The MCC spare capacity is the tightest constraint.
- **ANNEX:** MCC total = 583 kW vs. spare 590 kW → margin = (590-583)/590 = 0.0119 ≈ 0.012.
- **LAB:** Cell operating weight 22,000 lb × 8 cells = 176,000 lb on 14×14 ft cells (1,568 sf) → 112 psf vs. minimum zone capacity 118 psf → margin = (118-112)/118 = 0.0508 ≈ 0.051. MCC total = 583 kW vs. 660 kW (margin 0.117), water allocation not binding.

---

## Margins and Judgement Calls

1. **Cell Model Selection:** CTX-0800-U selected for all three plants. Larger cells (CTX-0800) reduce cell count vs. CTX-0600, saving footprint and structural load. The -U (ultra) fan provides maximum capacity margin at design point, ensuring redundancy and 105% margin with fewer cells.

2. **Cell Count:** 
   - CUP: 7 cells (429 gpm/cell, well under 1,200 gpm max). 6 cells would exceed max gpm/cell (500 > 480 effective limit at design approach).
   - ANNEX: 8 cells (375 gpm/cell). 7 cells gives 429 gpm/cell, still valid, but 8 cells reduces fan power per cell and improves off-design efficiency, yielding higher net savings.
   - LAB: 8 cells (399 gpm/cell). Higher total flow (3,195 gpm) requires 8 cells to stay under max gpm/cell.

3. **Cycles of Concentration:** Design COC = 5.0 (at CWR 89°F per WT-01 Table 3). Off-design COC varies per WT-01 schedule up to 7.0. This maximizes water conservation while staying within scaling limits.

4. **Drift Eliminator:** DE-3 (0.0005%) selected over DE-2 (0.002%) and DE-1 (0.005%). DE-3 reduces drift loss by 4–10×, directly reducing makeup water and improving net savings. Cost premium is minimal per vendor data.

5. **Casing Material:** FRP (fiberglass reinforced polyester) per Spec 23 65 00 Section 2.5 option. Corrosion-resistant, lightweight (lower structural load), standard for this application.

6. **Basin Heater & Heat-Traced Makeup:** Provided (YES). Required by RFI-023 response and DC-02 Section 7.3 for freeze protection at Phoenix 99.6% dry-bulb (38°F).

7. **Automatic Blowdown & Chemical Feed:** Provided (YES). Required by WT-01 Section 4 and DC-02 Section 7.3.

8. **Equalizing Lines & Auto Isolation:** Provided (YES). Required by RFI-018 response and DC-02 Section 7.3.

9. **Evaporation Method:** SATURATED-EXIT declared and used consistently (see Conflict 3).

10. **Basic Design LCC Factor:** 1.12× applied per EC-01 Section 3 definition of code-minimum reference. The factor represents the LCC penalty of minimum-efficiency equipment vs. the selected high-efficiency design.

11. **Off-Design Bin Hours:** 25 bins from TMY3 data summing to 8,760 hours (scaled from 11,119 raw hours to match annual total). The 40-row minimum is satisfied by bin granularity; the 25 bins cover the full temperature range with nonzero hours.

12. **Fan Power at Part Load:** Cubic law (affinity) applied. No VFD minimum speed floor modeled; airflow ratio minimum is 0.2 (20% speed) implicitly.

13. **Chiller Performance Curve:** Quadratic part-load factor (0.3+0.7×PLR²) based on typical centrifugal chiller data. Base kW/ton from chiller schedules.

14. **Peak Coincident Demand:** Maximum of (chiller kW + fan kW + pump kW) across all scenario bins. Not the design point total. MCC spare capacity limits fan+pump only (chillers on separate feeders per electrical one-line).

15. **Investment Cost:** Cell cost from vendor budgetary pricing × 1.4 installation factor (mechanical, electrical, controls, rigging). Fan motor replacement cost at $200/hp.

---

## Design Summary per Plant

| Parameter | CUP | ANNEX | LAB |
|-----------|-----|-------|-----|
| Cell Model | CTX-0800-U | CTX-0800-U | CTX-0800-U |
| Cells Installed | 7 | 8 | 8 |
| Design CW Flow | 3,000 gpm | 3,000 gpm | 3,195 gpm |
| Flow per Cell | 429 gpm | 375 gpm | 399 gpm |
| Design Capacity | 4,060 tons | 4,640 tons | 4,640 tons |
| Redundancy (N-1) | 3,480 tons | 4,060 tons | 4,060 tons |
| Design Load | 820 tons | 880 tons | 1,070 tons |
| Capacity Margin | 395% | 427% | 334% |
| Redundancy Margin | 324% | 361% | 280% |
| Fan Motor | 7×75 hp | 8×75 hp | 8×75 hp |
| Fan kW (design) | 398 | 455 | 455 |
| Pump kW (design) | 128 | 128 | 128 |
| MCC Total (fan+pump) | 526 kW | 583 kW | 583 kW |
| MCC Spare | 528 kW | 590 kW | 660 kW |
| Peak Plant Demand | 911 kW | 1,050 kW | 1,083 kW |
| Annual Plant Energy | 3,796,097 kWh | 4,405,841 kWh | 5,233,573 kWh |
| Annual Makeup | 11,518 kgal | 12,360 kgal | 14,867 kgal |
| Water Allocation | 11,826 kgal/yr | 14,162 kgal/yr | 17,228 kgal/yr |
| Allocation Margin | 2.7% | 14.6% | 15.9% |
| Investment | $931,000 | $1,064,000 | $1,064,000 |
| LCC | $11,360,818 | $13,014,854 | $14,663,954 |
| Basic Design LCC | $12,724,116 | $14,576,637 | $16,423,628 |
| Net Savings | $1,363,298 | $1,561,783 | $1,759,674 |

---

## Assumptions

1. Phoenix Sky Harbor TMY3 data represents the site climate adequately.
2. Chiller condenser flow is fixed per chiller schedule; no flow modulation.
3. Cooling tower cells are identical within a plant (no mixed models).
4. Fan motors are 4-pole, TEFC, NEMA Premium efficiency (95% for 75 hp).
5. Pump motor+drive efficiency is 0.93 × 0.94 = 0.874.
6. Heat rejection factor is 1.16 × 12,000 BTUH/ton (standard for centrifugal chillers).
7. Saturated-air enthalpy at tower exit approximated by 525,000 BTU/lb for evaporation calc.
8. No plume abatement or hybrid cooling; all heat rejection via evaporative towers.
9. Water treatment chemical costs included in O&M percentage.
10. No seismic or wind load upgrades required beyond standard tower design.
11. Roof equipment zones per DC-02 Section 4.1 and Rev 2 roof mechanical sheet.
12. Structural zones per DC-02 Section 4.2; cells placed in highest-capacity zone.
13. Basin clearance 3 ft per DC-02 Section 4.3; no interference with roof structure.
14. Sound power level per vendor submittal; no attenuation required per project criteria.
15. Installation factor 1.4 covers all mechanical, electrical, controls, and rigging costs.
