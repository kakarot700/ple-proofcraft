# Method of Procedure: PCW Flushing, Cleaning, and Passivation
## Tull Creek Data Hall — Turnover Package

**Project:** Tull Creek Data Hall PCW Loop  
**Contractor:** Flushing Contractor  
**Document:** MOP-PCW-001 Rev 0  
**Date:** 2026-01-15

---

## 1. SCOPE

This Method of Procedure (MOP) governs the flushing, chemical cleaning, rinsing, passivation, and final fill of the eight (8) tie-in-bounded Process Cooling Water (PCW) circuits in the Tull Creek Data Hall. The PCW loop is mechanically complete and divided into the following circuits per M-603 Tie-in Schedule and P&IDs M-PID-101 through M-PID-104:

| Circuit | Description | Tie-in | P&ID | Metallurgy | Flush Volume (gal) | System Volume (gal) |
|---------|-------------|--------|------|------------|-------------------|---------------------|
| C1 | PCW Primary Header & Pump Gallery | MER-1 | M-PID-101 | CS/Cu | 32,983 | 32,983 |
| C2 | PCW HX Bay A | MER-1 | M-PID-102 | CS/SS | 5,596 | 7,946 |
| C3 | PCW HX Bay B | MER-2 | M-PID-102 | CS/SS | 6,203 | 8,553 |
| C4 | PCW CDU Distribution North | L3-N | M-PID-103 | CS/Cu/Al | 5,957 | 8,537 |
| C5 | PCW CDU Distribution South | L3-S | M-PID-103 | CS/Cu/Al | 6,406 | 8,986 |
| C6 | PCW CDU Distribution West | L3-W | M-PID-103 | CS/Cu/Al | 4,227 | 5,677 |
| C7 | PCW Fan-Wall Coil Branch | ROOF | M-PID-101 | Cu | 4,086 | 6,036 |
| C8 | PCW Makeup & Fill Riser | YARD | M-PID-104 | Galv | 5,791 | 5,791 |

---

## 2. DESIGN BASIS

### 2.1 Governing Constraints and Margins

For each circuit, the governing constraint is the one leaving the least margin among the five critical limits. The margin is calculated as `(limit - achieved) / limit`.

| Circuit | Governing Constraint | Margin | All Margins |
|---------|---------------------|--------|-------------|
| C1 | Discharge volume | 50.0% | Flushing head: 77.0%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 50.0% |
| C2 | Discharge volume | 50.0% | Flushing head: 55.1%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 60.0% |
| C3 | Temporary power | 36.8% | Flushing head: 51.7%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 36.8% |
| C4 | Temporary power | 7.7% | Flushing head: 41.3%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 7.7% |
| C5 | Temporary power | 7.7% | Flushing head: 24.9%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 7.7% |
| C6 | Temporary power | 7.7% | Flushing head: 48.5%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 7.7% |
| C7 | Temporary power | 25.0% | Flushing head: 59.3%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 25.0% |
| C8 | Temporary power | 14.3% | Flushing head: 80.2%, Rinse endpoint: 90.0%, Discharge volume: 50.0%, Water allocation: 50.0%, Temporary power: 14.3% |


### 2.2 Key Design Decisions

**Flushing Velocity:** Per UFC 3-230-13 Section 6.2.2, minimum 2.0 ft/s for piping, 4.0 ft/s for heat exchangers (C2, C3) and cold plates (C4, C5, C6). Governing segments and required flows calculated per pipe schedule.

**Skid Assignment:** Rented fleet comprises FS-600-A (30 kW), FS-600-B (30 kW), and FS-1200-A (75 kW, available hour 48). 
- C1 (720 gpm) requires FS-1200-A (only skid delivering >600 gpm at positive head).
- C2, C3 (624, 720 gpm) require both FS-600 skids in parallel (312/360 gpm each).
- C4, C5, C6 (360, 476, 360 gpm) require both FS-600 skids in parallel.
- C7 (180 gpm) uses single FS-600-A.
- C8 (92 gpm) uses single FS-600-B.
All assignments verified against skid pump curves with 300 ft hose; head margins range 25–80%.

**Treatment Programs (UFC 3-230-13 Table 6-2):**
- CS/SS/Cu (C1, C2, C3, C7): Nitrite-azole (NB-700), 800 ppm NO₂, pH 8.5–9.5, 5-day hold.
- Al-containing (C4, C5, C6): Polysilicate-azole (PS-800), 90 ppm SiO₂, pH 7.5–8.9, 14-day hold (Al requires extended passivation).
- Galvanized (C8): Polysilicate-azole (PS-800), 90 ppm SiO₂, pH 7.5–8.9, 14-day hold.

**Chemical Cleaning:** 
- CS/SS/Cu: Alkaline cleaner CL-100 (2% wt, 6 hr circulation, pH ~10.5).
- Al/Galv: Neutral pH cleaner CL-210 (2% wt, 6 hr circulation, pH ~7.8).

**Rinse Strategy:** Three (3) system-volume displacements per UFC 3-230-13 Section 6.4. Rinse water cascaded where possible: C2→C3→C4→C5→C6→C7→C8. C1 and C2 use makeup water. Reduces total makeup draw by ~150,000 gal.

**Water Management:** Construction water allocation per SI-04: 31,000 gal/day (Days 1–5), 92,000 gal/day (Day 6+). Schedule staged to respect daily limits. Total makeup: ~363,000 gal.

**Discharge Management:** Single authorized point MH-14 per IWD-2026-0417. Limits: pH 6–9, temp ≤100°F, flow ≤150 gpm, ≤25,000 gal/day to sewer. Excess hauled. Chem clean discharge (high pH) hauled. Rinse/passivate/flush to sewer within limits.

**Temporary Power:** Per SW-04, available power at each tie-in limits concurrent skid power. All assignments within limits (max 60 kW on 65 kW service).

**Schedule:** Two crews, 45-day contractual turnover (Day 45). Critical path: C4–C6 14-day hold. All circuits complete by Day 20.2 (484 hours).

---

## 3. EXECUTION NARRATIVE

### 3.1 Mobilization (Day 0, Hour 0)
- Deliver FS-600-A, FS-600-B to site. Stage at MER-1 and YARD.
- Deploy CREW-1 to C7 (ROOF, FS-600-A), CREW-2 to C8 (YARD, FS-600-B) with 24-hr stagger for water limit.
- Install temporary strainers (1/8" perf), bypass spools at HX-201A/B, CP-311/321/331, CL-401.
- Verify isolation at tie-ins per M-603.

### 3.2 Hydrostatic Test (C7, C8 only)
- C1–C6 previously tested and accepted per CX-02 (127.5 psig, 120 min, PASS).
- C7, C8: Pressurize to 127.5 psig with construction water, hold 2 hours, inspect joints. Document on CX-02 form.

### 3.3 Initial Flush (All Circuits)
- Fill circuit from makeup (ST-601). Recirculate at ≥ required velocity for 7 system-volume displacements.
- Monitor turbidity at discharge; target ≤5 NTU.
- Discharge to sewer (within 25k gal/day limit).

### 3.4 Chemical Clean (All Circuits)
- Fill with cleaner solution (CL-100 or CL-210 per metallurgy) at 2% concentration.
- Circulate 6 hours at design flow. Monitor pH, iron/copper.
- Drain spent solution to haul (pH outside sewer limits).

### 3.5 Drain & Rinse (All Circuits)
- Three (3) displacements with makeup or cascaded water.
- Each displacement: fill, circulate 15 min, drain.
- Verify rinse endpoint: pH 6–9, conductivity <50 μS/cm, chloride <50 ppm.
- Discharge to sewer.

### 3.6 Passivate (All Circuits)
- Fill with inhibitor solution (NB-700 or PS-800 per program) at target concentration.
- Circulate 2 hours to establish film.
- Isolate circuit, apply nitrogen blanket 5 psig.
- Hold: 5 days (nitrite-azole) or 14 days (polysilicate-azole).

### 3.7 Final Fill & Turnover (All Circuits)
- Top up passivation solution to operating level with treated makeup.
- Verify turnover water quality: inhibitor >50% passivation dose, pH per program, conductivity <200 μS/cm, bacteria <1000 CFU/mL.
- Submit turnover package per CX-01 TM-4.

---

## 4. CONFLICT RESOLUTIONS AND JUDGEMENT CALLS

| Issue | Resolution | Basis |
|-------|------------|-------|
| C1 flow (720 gpm) exceeds FS-600 capability | Assign FS-1200-A; accept 48-hr delay | Only skid with >600 gpm at positive head |
| C2, C3, C4, C5, C6 need parallel FS-600s but only 2 units | Sequence sequentially on both skids | Fleet constraint; 2 crews but skid-limited |
| Rinse water volume exceeds daily sewer limit | Cascade rinse C2→C8; spread passes over days | IWD-2026-0417 sewer limit 25k gal/day |
| Day 0–5 water limit (31k gal/day) vs C7+C8 simultaneous start | Stagger C8 start by 24 hours | SI-04 reduced allocation Days 1–5 |
| C1 rinse (98,949 gal) exceeds daily makeup | Split rinse passes across Days 8–10 | Water allocation 92k gal/day Day 6+ |
| Al circuits require 14-day hold vs 45-day turnover | Start C4–C6 early; holds complete by Day 20 | Schedule float available |
| CL-100 pH 10.5 vs sewer pH limit 9.0 | Haul chem clean discharge; rinse to pH 6–9 | IWD-2026-0417 discharge conditions |
| FS-1200-A delivery at hour 48 | Start C1 at hour 48; parallel circuits on FS-600s before | RFI-017 response |

---

## 5. DEFECTS AND OPEN ITEMS

1. **C7, C8 Hydrostatic Test Not Performed:** Requires execution per this MOP. Risk: leaks delay schedule. Mitigation: test first on each circuit.
2. **Temporary Strainer Removal:** Not in schedule. Add 1 hour per circuit post-rinse for strainer removal and blind flange reinstall.
3. **Nitrogen Blanket Supply:** Not specified in temp utilities. Confirm availability or use alternative (vented hold with inhibitor top-up).
4. **Cascade Rinse Quality Verification:** Need conductivity/pH check on cascaded water before use. Add hold points.
5. **Chemical Delivery Lead Times:** NB-700/PS-800 15 days. Order by Day -15 (pre-mobilization). CL-100/CL-210 10 days. PH-ADJUST 5 days.

---

## 6. SAFETY — CHEMICAL HANDLING PER NFPA 704 / OSHA HCS (29 CFR 1910.1200)

The project specification adopts UFC 3-230-13, which references NFPA 704 and OSHA Hazard Communication Standard for chemical handling.

### 6.1 Chemical Hazards

| Product | NFPA 704 (H-F-R) | Primary Hazards | PPE Required |
|---------|------------------|-----------------|--------------|
| CL-100 | 2-0-0 | Alkaline, skin/eye irritant | Face shield, chem-resistant gloves, apron, boots |
| CL-210 | 1-0-0 | Mild irritant | Gloves, goggles |
| NB-700 | 2-0-0 | Nitrite (oxidizer), skin sensitizer | Gloves, goggles, dust mask for powder |
| PS-800 | 1-0-0 | Silicate, alkaline | Gloves, goggles |
| PH-ADJUST | 2-0-0 | Acidic, corrosive | Face shield, acid-resistant gloves, apron |

### 6.2 Safety Requirements

1. **SDS Access:** Current SDS for all products at point of use (per 29 CFR 1910.1200(g)).
2. **Labeling:** All containers labeled per GHS (product ID, hazard pictograms, signal word, precautionary statements).
3. **Mixing:** Add chemical to water, never water to chemical. Use calibrated metering pumps.
4. **Ventilation:** Ensure adequate ventilation at mixing stations; monitor for ammonia/nitrite fumes.
5. **Spill Response:** Neutralization kits (citric acid for alkaline, soda ash for acid) staged at each tie-in. Spill containment berms under mixing totes.
6. **Decontamination:** Eyewash/shower within 10 sec/55 ft of chemical handling areas. Verify functional daily.
7. **Training:** All crew members trained on specific chemical hazards, PPE, and emergency procedures before handling.
8. **Waste Handling:** Spent CL-100 (pH ~10.5) and CL-210 (pH ~7.8) collected in DOT-approved totes, hauled to permitted facility. Rinse water to sewer per IWD-2026-0417.
9. **Confined Space:** Pipe/equipment entry for strainer removal requires permit per 29 CFR 1910.146. Atmosphere test for O₂, H₂S, CO, LEL.
10. **Lockout/Tagout:** All energy sources (pumps, valves, electrical) isolated per 29 CFR 1910.147 before breaking containment.

### 6.3 Emergency Contacts

- Site Safety: (on-site radio Channel 1)
- Medical: Tull Creek Medical Clinic, 555-0199
- Chemtrec: 1-800-424-9300 (for SDS/emergency guidance)
- Spill Reporting: NC DEQ 24-hr 1-800-858-0368

---

## 7. TURNOVER PACKAGE CONTENTS

Per CX-01 TM-4, each circuit turnover package includes:
1. Completed flush_plan.csv rows for circuit
2. Completed chemistry_plan.csv rows for circuit
3. Acceptance matrix with all gate sign-offs
4. Hydrostatic test record (CX-02) or waiver (C1–C6)
5. Chemical lot certificates and SDS
6. Water analysis (makeup and final fill)
7. Discharge logs (sewer/haul manifests)
8. Nitrogen blanket verification (hold period)
9. Final water quality lab report
10. P&ID mark-ups showing as-flushed configuration

---

**Prepared by:** Commissioning Engineer, Flushing Contractor  
**Approved by:** _________________________ **Date:** _______________  
**Client Acceptance:** _________________________ **Date:** _______________
