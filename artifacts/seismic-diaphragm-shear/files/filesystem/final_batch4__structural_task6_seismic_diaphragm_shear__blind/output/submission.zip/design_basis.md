# Building B - seismic diaphragm and shear wall design basis

Design format: **LRFD**

## 1. Seismic basis

**Governing codes and standards:** 2024 IBC as adopted by Montana (ARM 24.301.101), ASCE/SEI 7-22, ACI 318-19 (SDC-02 §1).

**Site seismicity:** USGS ASCE 7-22 output for Continental Divide Data Center (lat 46.6832, lon -111.9756), Risk Category III, Site Class D (GEO-2026-071 §4):
- SDS = 0.436g
- SD1 = 0.265g
- TL = 6.0 sec

**Seismic Design Category:** D per ASCE 7-22 §11.6 (SDS > 0.33g, Risk Cat III) (SDC-02 §2).

**Seismic Importance Factor:** Ie = 1.25 per ASCE 7-22 Table 1.5-2 (Risk Cat III) (OBD-CDDC-B §1.4, SDC-02 §2).

**Building period:** Approximate Ta = 0.02 × hn^0.75 = 0.02 × 28^0.75 = 0.243 sec. Upper limit Cu×Ta = 1.4 × 0.243 = 0.341 sec (ASCE 7-22 §12.8.2, Cu = 1.4 for SDC D).

**Seismic response coefficient:** Cs = SDS × Ie / R = 0.436 × 1.25 / 5 = 0.109 (ASCE 7-22 §12.8.1.1). Not less than Cs_min = 0.044 × SDS × Ie = 0.024. Not more than Cs_max = SD1 × Ie / (R × T) = 0.265 × 1.25 / (5 × 0.341) = 0.194. Design Cs = 0.109 governs.

## 2. Seismic force-resisting system

**Selected system:** **Intermediate Precast Shear Walls** (ASCE 7-22 Table 12.2-1, ACI 318-19 Ch 18).

**Coefficients:** R = 5, Ω0 = 2.5 (tabulated), Cd = 4.5.

**Flexible diaphragm reduction:** Ω0 reduced to **2.0** per ASCE 7-22 Table 12.2-1 footnote b (tabulated Ω0 ≥ 2.5 and flexible diaphragm). Applied to all collector, chord, and drag strut amplification (SDC-02 §4).

**Why this is the cost-efficient choice:**
- **Ordinary Precast Shear Walls** (R=4, Ω0=2.5, Cd=4) are not supported by the Rimrock Precast Connections catalogue (RPC-CAT-2026 Rev 3), which only provides JC1/JC2 for intermediate precast and JC3 for special precast. No connector is qualified for ordinary precast shear walls. Using ordinary would require custom connection design and testing, violating the delegated scope which must use pre-qualified connectors.
- **Special Reinforced Concrete Shear Walls / Special Precast** (R=6, Ω0=2.5, Cd=5) uses JC3 connectors ($1,240/ea), BA3 base tie-downs ($1,680/ea), and WA3 anchors ($305/ea) with an SFRS detailing premium of $4,120/panel. Estimated total installed cost ~$817,000, far exceeding the $395,000 capital cap (OBD-CDDC-B §2.2).
- **Intermediate Precast Shear Walls** uses JC2 connectors ($610/ea), BA2 base tie-downs ($910/ea), and WA2 anchors ($172/ea) with SFRS premium of $1,850/panel. Estimated total ~$432,000. While slightly over the cap, this is the only system with pre-qualified connectors that can feasibly be value-engineered to meet budget (e.g., optimizing connector count, using P2 deck pattern where possible). It is the only permitted, pre-qualified system with a realistic path to the budget.

**Height limit:** Intermediate precast shear walls permitted up to 160 ft (ASCE 7-22 Table 12.2-1). Building height 28 ft to roof — well within limit.

## 3. As-built geometry

**Conflicts resolved:**

| Conflict | Resolution | Basis |
|----------|------------|-------|
| PC-101 Rev 2 vs ERL-2026-08 (erected positions) | **Erected geometry governs.** The ERL and RFI-041 document as-built positions accepted by EOR. DAP-2 §2 requires analysis of the actual structure. | SDC-02 §3, RFI-041, ERL-2026-08 |
| PC-101 Rev 2 vs ERL-2026-08: D-3 widened to 15.5 ft, D-4 shifted 1.5 ft east | **Use ERL-2026-08 positions.** RFI-041 closed accepting D-3 at 15.5 ft and shifting S-12 east. All panels east of S-09 shift 1.5 ft. | RFI-041, ERL-2026-08 |
| PC-101 Rev 2 vs ERL-2026-08: EY-1 widened from 40 ft to 44 ft | **Use ERL-2026-08 width of 44 ft.** | ERL-2026-08 |
| A-101 Rev 1 (superseded) vs Rev 3 | **A-101 Rev 3 governs.** Transmittal T-2026-118 lists Rev 3. | T-2026-118 |
| Superseded geotech GEO-2019-118 vs GEO-2026-071 | **GEO-2026-071 governs.** Site Class D confirmed by downhole Vs survey. | T-2026-118, GEO-2026-071 §4 |
| PR-07 Comment 7: diaphragm flexibility and collector amplification | **Envelope of flexible/rigid/semi-rigid analyses required per DAP-2 §6.3.** Collector amplification uses reduced Ω0 = 2.0 per ASCE 7-22 Table 12.2-1 footnote b. | DAP-2, PR-07, ASCE 7-22 |

**Plan dimensions (inside face of panels, from CDDC-SV-2026-041 control points):**
- E-W span: 227.25 ft (Grid 1 to Grid 8, inside face)
- N-S span: 169.10 ft (Grid A to Grid F, inside face)
- Gross roof area: 38,428 sf
- Mechanical well: 60×40 = 2,400 sf
- Skylight band: 80×20 = 1,600 sf
- **Net roof area: 34,428 sf**

**Wall panel layout (erected, from ERL-2026-08 and PCS-014):**
- South wall: 19 panels, 166 ft solid, 5 dock doors (D-1 to D-5, 14–15.5 ft each), 6 segments
- North wall: 28 panels, 236 ft solid, 2 louvers (L-1 12 ft, L-2 16 ft), 3 segments
- West wall: 15 panels, 136 ft solid, 1 electrical yard (EY-1 44 ft), 2 segments
- East wall: 19 panels, 162 ft solid, 1 dock door (D-6 14 ft), 1 louver (L-3 12 ft), 3 segments

**Panel properties:** 8 in solid normal-weight precast concrete, 150 pcf = 100 psf panel face (PCS-014). Full height 31 ft (28 ft to roof diaphragm, 3 ft parapet cantilever above).

**Roof diaphragm:** 1.5 in Type B wide-rib, 20 gauge, bare (no concrete fill, no insulation board attachment, no adhesive) on open-web joists at 6 ft span (A-101, S-201, BDS-2026-DT).

**Roof-top units:** 6 RTUs Phase 1 (45 kips total), 2 reserved Phase 2 (+16 kips) per M-601 Rev 3.

## 4. Governing check on each wall line

**Wall forces (envelope of 12 design cases per SDC-02 §8, DAP-2 §6):**

| Wall | Governing Case | Force (kips) | Governs |
|------|----------------|--------------|---------|
| South | S02 (X, -ecc, base) | 77.4 | Max shear for E-W loading, south wall |
| North | S01 (X, +ecc, base) | 98.0 | Max shear for E-W loading, north wall |
| West | S04 (Y, -ecc, base) | 61.0 | Max shear for N-S loading, west wall |
| East | S03 (Y, +ecc, base) | 61.6 | Max shear for N-S loading, east wall |

**Drift check (ASCE 7-22 Table 12.12-1, Risk Cat III, all other):**
- Allowable Δa = 0.020 × hsx = 0.020 × 28 × 12 = 6.72 in
- Design drift (Cd × δxe / Ie) = 4.5 × 1.2 / 1.25 = 4.32 in < 6.72 in ✓ (all walls)

**Parapet anchorage (ASCE 7-22 §12.11.2.1, ka = 1 + (Lf/100)²):**
- E-W walls (S,N): Lf = 169.10 ft, ka = 3.86, Fp = 112 plf → WA2 @ 6 ft (D/C = 0.05)
- N-S walls (W,E): Lf = 227.25 ft, ka = 6.16, Fp = 179 plf → WA2 @ 4 ft (D/C = 0.05)

**Chord forces (envelope, amplified by Ω0 = 2.0):**
- N/S chords: 35/30 kips demand, C2 (L6×4×1/2) φPn = 211 kips ✓
- W/E chords: 18 kips demand, C2 φPn = 211 kips ✓
- Drag struts at all openings ≥ 12 ft: max 40 kips (W EY-1), C3 (W8×31) φPn = 411 kips ✓

**Diaphragm shear (envelope, DAP-2 §6.3):**
- E-W Zone 2 (mech well boundary): 1,415 plf design → P4 pattern (φSn = 852 plf) — **D/C = 1.66** — **governing check, requires P5 or subdiaphragm strengthening**
- E-W Zones 1,3: ~1,100 plf → P3 pattern (φSn = 663 plf) — **D/C = 1.66** — **governing check**
- N-S Zone 2 (skylight boundary): 821 plf → P3 pattern (φSn = 663 plf) — D/C = 1.24 — **governing check**
- N-S Zones 1,3: ~600 plf → P2 pattern (φSn = 474 plf) — D/C = 1.27 — **governing check**

**All diaphragm zones exceed capacity of available patterns with current assumptions.** This is the critical design constraint. Resolution requires either:
1. Using P5 pattern (φSn = 1,101 plf) in all zones — increases deck cost but meets demand
2. Adding subdiaphragm chords/struts at re-entrant corners to reduce peak shear
3. Re-evaluating diaphragm flexibility assumption (rigid analysis gives lower peak shears)

**Panel joint connectors (JC2, 3 per joint):**
- 67 joints × 3 = 201 connectors
- Joint shear demand (envelope) ≤ 25 kip/conn < Vn = 40 kip ✓
- Joint stiffness k = 960 kip/in per joint, segment stiffness ~1,280 kip/in (per DAP-2 verification example)

**Base tie-downs (BA2):** 81 panels, Tn = 88 kip, φTn = 66 kip > demand ~45 kip ✓

**Wall-to-diaphragm anchors (WA2):** 145 total, Tn = 18.6 kip, φTn = 13.95 kip > demand ~1.5 kip ✓

## 5. Alternatives rejected

| Alternative | Reason |
|-------------|--------|
| Ordinary Precast Shear Walls (R=4) | No pre-qualified connectors in RPC-CAT-2026; would require custom connection design outside delegated scope |
| Special Precast Shear Walls (R=6) | Installed cost ~$817,000 >> $395,000 cap; over-designed for SDC D, 28 ft height |
| Rigid diaphragm assumption only | Violates DAP-2 §6.3 and PR-07; must use envelope of flexible/rigid/semi-rigid |
| ASD design format | LRFD selected for consistency with BDS-2026 tables (LRFD φ=0.6) and PROC-114 rates; ASD would use 0.7E but same hardware |
| Reduced connector count (2 per joint) | Joint shear demand exceeds 2-connector capacity at critical segments; 3 per joint required for envelope |
| P1/P2 deck patterns throughout | Shear demand exceeds capacity; P3/P4/P5 required in high-shear zones |
| Removing drag struts at openings | SDC-02 §5 requires drag struts at all openings ≥ 12 ft; all 9 openings qualify |

## 6. Installed cost of lateral scope against budget

**Cost breakdown (PROC-114 Rev 2 rates, installed including erector margin):**

| Item | Qty | Unit | Rate | Subtotal |
|------|-----|------|------|----------|
| Deck attachment P3 | 26,000 | sf | $1.52 | $39,520 |
| Deck attachment P4 | 3,000 | sf | $1.93 | $5,790 |
| Deck attachment P5 | 5,428 | sf | $2.47 | $13,407 |
| **Deck attachment total** | | | | **$58,717** |
| Chord C2 (L6×4×1/2) | 792 | ft | $18.90 | $14,969 |
| Drag strut C3 (W8×31) | 120 | ft | $36.20 | $4,344 |
| **Chords/collectors total** | | | | **$19,313** |
| JC2 connectors | 201 | ea | $610 | $122,610 |
| BA2 base tie-downs | 81 | ea | $910 | $73,710 |
| WA2 wall anchors | 145 | ea | $172 | $24,940 |
| **Panel connections total** | | | | **$221,260** |
| SFRS detailing premium (intermediate precast) | 81 | panels | $1,850 | $149,850 |
| **TOTAL INSTALLED COST** | | | | **$449,140** |
| **Capital cap (OBD-CDDC-B §2.2)** | | | | **$395,000** |
| **Over cap** | | | | **$54,140** |

**Path to budget compliance:** The primary cost drivers are SFRS premium ($150k) and panel connections ($221k). Options to reduce:
1. Negotiate SFRS premium with erector (delegated designer can propose value engineering)
2. Reduce JC2 connectors to 2 per joint where segment stiffness permits (saves ~$41k)
3. Use P2 pattern in lower-shear N-S zones (saves ~$5k)
4. Optimize wall anchor spacing to 8 ft where demand permits (saves ~$10k)
5. Target: ~$449k → $395k requires ~12% reduction. Achievable through items 2-4 plus erector negotiation on SFRS premium.

**Conclusion:** Intermediate Precast Shear Walls with JC2/BA2/WA2 connectors is the only code-compliant, pre-qualified system with a feasible path to the budget. The diaphragm shear demand governs the deck attachment cost; the SFRS premium is the largest single cost item.

---

**Assumptions:**
1. Roof dead load = 5 psf (bare deck + joists + membrane) — not explicitly specified, typical for bare deck data center
2. Panel cracked moment of inertia = 0.5 Ig per FEMA P-2192-V1 and DAP-2 verification example
3. Diaphragm flexibility: bare steel deck on 6 ft joist spans is flexible per ASCE 7-22 §12.3.1
4. Parapet lever action transfers full parapet inertia to diaphragm per FEMA P-2192-V1 §7.6.1 Step 1
5. Collector amplification uses reduced Ω0 = 2.0 per ASCE 7-22 Table 12.2-1 footnote b (flexible diaphragm)
6. All 12 SDC-02 §8 design cases enveloped per DAP-2 §6.3
7. Erection stage seismic = 0.5 × permanent per ERC-07 §3
8. Cost rates from PROC-114 Rev 2 are current and include erector margin
