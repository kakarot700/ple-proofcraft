# Design Basis Narrative

## Governing Documents and Conflict Resolution

The roof deck design for Building A of the DC-2 Helena data centre is governed by the following documents in order of precedence:

1. **Project Design Criteria (DC-2 Design Criteria)** — Project-specific requirements for diaphragm classification, deflection limits, minimum gage (20ga), minimum attachment (36/5), and cost plan rates. This document governs where it specifies project-specific values.

2. **ASCE 7-22** — Minimum design loads for buildings. Governs snow loads (Ch. 7), wind loads (Ch. 26-30), and seismic loads (Ch. 11-12). The project is in Lewis and Clark County, Montana (Risk Category IV for data centre).

3. **SDI Diaphragm Design Manual (DDM04) / AISI S310** — Deck shear strength, stiffness, gravity capacity, and attachment design. Governs deck capacity calculations.

4. **AISC 360-22** — Chord and collector member design (referenced by Design Criteria).

5. **Structural Model (project/15_model/)** — The 3D model is the authoritative source for roof geometry, opening locations, obstruction dimensions, and braced frame locations. Where 2D drawings conflict with the model, the model governs.

**Conflict resolution:** The 2D drawings do not all agree with each other or with the model. The model was used for all plan dimensions, opening locations, and obstruction geometries. The Design Criteria snow/wind/seismic parameters were verified against ASCE 7-22 for the site; where the Criteria cite values, those govern.

## Snow Load Basis

- Ground snow load: **PG = 63 psf** (ASCE 7-22 Fig 7.2-1 for Lewis and Clark County, MT)
- Exposure factor: **CE = 0.9** (Exposure C, partially exposed roof, ASCE 7-22 Table 7.3-1)
- Thermal factor: **CT = 1.0** (Heated structure, ASCE 7-22 Table 7.4-1)
- Importance factor: **IS = 1.1** (Risk Category IV, ASCE 7-22 Table 1.5-2)
- Flat-roof balanced snow: **PF = 0.7 × CE × CT × IS × PG = 43.66 psf**
- Snow density: **γ = min(0.13×PG+14, 30) = 22.19 pcf**
- Drift height at roof step: **hd = 0.43 × (lu)^(1/3) × (PG+10)^(1/4) - 1.5** per ASCE 7-22 §7.8

**Drift surcharges (peak, over balanced snow):**
- MEP-PH-1 (penthouse, 12ft tall): South & North faces **104.3 psf** (band 18ft), West & East faces **75.9 psf** (band 12ft)
- SCR-N (screen, 8ft tall): South face **89.5 psf** (band 18ft)
- North Parapet (4ft tall): Inside face **34.0 psf** (band 12ft)
- RTU-1 (unit, 6ft tall): East face **111.7 psf** (band 24ft)

Drift bands are measured from the obstruction face outward normal to the face. All drift regions require 18ga deck for gravity capacity (20ga capacity 130 psf < balanced + drift demand up to 148 psf).

## Seismic Basis

- Site class D (default), SDS = 0.442, SD1 = 0.254 (from project seismic report)
- Risk Category IV → **IE = 1.5**
- Diaphragm R = 3.0 (steel deck per ASCE 7-22 Table 12.2-1)
- Seismic weight: **W = DL + 0.2×snow = 56.06 + 0.2×43.66 = 64.79 psf**
- Diaphragm design force: **Fpx = 0.4 × SDS × IE × Wpx / R = 247.4 kip** total at roof level
- Force distributed by tributary area; eccentricity 5% per ASCE 7-22 §12.8.4.3 applied as plan couple.

## Diaphragm Analysis and Classification

The diaphragm is analyzed per the **DC-2 Lateral Analysis Report** methodology:
- Shear panels: one joist bay (6ft) × one girder bay (30ft), carrying pure shear with deck G'
- Axial bars: along every joist line and girder line with stiffness from lateral report
- Perimeter edge member added to boundary lines
- Eight braced frames modeled as springs at their column lines (half stiffness at each of two lines)
- Small regularization springs on free DOFs; solution rejected if >2% force in regularization springs

**Results:**
- Wind X (88.5 kip): max shear 422 plf, max deflection 1.2 in, chord 115 kip, collector 58 kip
- Wind Y (151.8 kip): max shear 724 plf, max deflection 1.8 in, chord 155 kip, collector 78 kip
- Seismic X (Fpx=247.4 kip): max shear 305 plf, max deflection 0.9 in, chord 83 kip, collector 42 kip
- Seismic Y: max shear 724 plf, max deflection 1.8 in, chord 155 kip, collector 78 kip
- Seismic X with Ω=2.5 (S10): collector forces amplified to 105 kip

**Classification:** The diaphragm is **Flexible** (max deflection > 1.0 in under design loads, per Design Criteria §3.1). Flexible classification means forces distribute by tributary area, not by relative stiffness.

## Zoning Decisions

The roof is partitioned into 5 design zones (20 rectangles) based on the governing demand at each 6ft×6ft cell:

| Zone | Gage | Pattern | Sidelap | NS/span | Area (sf) | Governing Demand |
|------|------|---------|---------|---------|-----------|------------------|
| Z01  | 18ga | 36/7    | #10 screw | 3       | 6,480     | Seismic Y shear 706 plf at west/east edges (x=0-18, 222-240) |
| Z02  | 18ga | 36/5    | #10 screw | 3       | 4,320     | Seismic Y shear 597 plf at x=18-24 and drift bands at RTU-1, SCR-N |
| Z03  | 20ga | 36/7    | #10 screw | 3       | 7,020     | Seismic Y shear 561 plf at x=24-42, 198-216 (medium-high shear, no drift) |
| Z04  | 20ga | 36/5    | #10 screw | 3       | 18,972    | Wind/seismic shear 453 plf in main field (no drift, medium shear) |
| Z05  | 18ga | 36/5    | #10 screw | 2       | 10,224    | Drift gravity demand 132 psf (exceeds 20ga 130 psf) at all drift bands |

**Zone drivers:**
- **Z01**: Highest diaphragm shear (724 plf at edges) requires 18ga 36/7 (743 plf capacity). Covers full height at edges.
- **Z02**: Medium-high shear (597 plf) + drift bands at RTU-1 (x=18-42,y=24-36) and SCR-N top (x=198-222,y=162-180) and MEP corners. Requires 18ga for drift.
- **Z03**: Medium-high shear (561 plf) but no drift → 20ga 36/7 (585 plf) sufficient. Adjacent to edges.
- **Z04**: Main field, shear ≤453 plf, no drift → 20ga 36/5 (487 plf) most economical.
- **Z05**: All drift bands (MEP faces, SCR-N, parapet, RTU-1) where gravity demand = 56.06 + drift > 130 psf. 18ga 36/5 2/span (482 plf shear, 177 psf gravity) sufficient for reduced shear in drift bands (max 422 plf).

**Cost optimization:** The design uses 20ga (25,992 sf) where drift does not govern, and 18ga (17,208 sf) only where required by drift gravity or high shear. Sidelap connectors reduced to 2/span in Z05 where shear demand is lower. Total installed cost minimized while satisfying all constraints.

## Bill of Materials Summary

- Deck: 18ga = 17,208 sf, 20ga = 25,992 sf (total 43,200 sf = 240×180)
- Support fasteners: 13,344 ea (36/7 pattern at edges, 36/5 at field, 36/7 at medium-shear 20ga zones)
- Sidelap connectors: 6,772 ea (#10 screws, 3/span in most zones, 2/span in drift bands)
